export class Refugio {}
