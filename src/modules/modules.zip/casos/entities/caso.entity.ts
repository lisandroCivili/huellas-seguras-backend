export class Caso {}
