export class Veterinaria {}
