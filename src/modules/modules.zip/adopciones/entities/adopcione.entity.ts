export class Adopcione {}
